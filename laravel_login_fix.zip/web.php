<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\KategoriController;

// LOGIN
Route::get('/login', [AuthController::class,'showLogin'])->name('login');
Route::post('/login', [AuthController::class,'login']);
Route::post('/logout', [AuthController::class,'logout'])->name('logout');

// ADMIN
Route::prefix('admin')->middleware('auth')->group(function () {

    Route::get('/dashboard', [AdminController::class,'dashboard'])
        ->name('admin.dashboard');

    Route::resource('kategori', KategoriController::class);
});

// SISWA
Route::prefix('siswa')->middleware('auth')->group(function () {

    Route::get('/dashboard', [SiswaController::class, 'dashboard'])
        ->name('siswa.dashboard');
});
